App({
  onLaunch: function() {
    wx.getSystemInfo({
      success: res => {
        //导航高度
        this.globalData.height = res.statusBarHeight
      },
      fail(err) {
        console.log(err);
      }
    })
  },
  globalData: {
    height: 0
  }

})