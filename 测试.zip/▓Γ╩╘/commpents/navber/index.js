const app = getApp()
Component({
  data: {
    navbarData: {
      title:"巴拉巴拉巴拉"
    }
  },
  attached: function () {
    // 定义导航栏的高度   方便对齐
    this.setData({
      height: app.globalData.height
    })
  }

})